window.AUDITORIA={
 "PLATAFORMAS": {
  "filas": 45945,
  "columnas": [
   "Fecha",
   "Plataforma",
   "Tienda",
   "Razón social",
   "Categoría",
   "SKU CORRECTO",
   "Título",
   "Ubicación",
   "Total",
   "Costo",
   "Costo Inventario",
   "Costo Inventario + IVA"
  ],
  "cortes": [
   "2026-10-01",
   "2026-10-02",
   "2026-10-05",
   "2026-10-09",
   "2026-10-12",
   "2026-10-16",
   "2026-10-19",
   "2026-10-21"
  ],
  "skus": 2460,
  "tiendas": [
   "ARMAF",
   "MEDICAL STORE",
   "MISS ROU",
   "MX LOVERS",
   "NEXU STORE",
   "OCENID",
   "SELECTSHOP",
   "SIGNA",
   "T-LAB"
  ],
  "canales_o_almacenes": [
   "AMAZON",
   "COPPEL",
   "LIVERPOOL",
   "MERCADO LIBRE",
   "WALMART"
  ],
  "ubicaciones_o_estatus": [
   "Aptas para vender",
   "Devueltas por el comprador",
   "En revisión",
   "En transferencia",
   "Extraviadas (en búsqueda)",
   "No aptas para vender",
   "Pendientes de ingreso"
  ],
  "nulos": {},
  "titulos_con_error": 0,
  "skus_titulo_error": [],
  "total_negativo": 0,
  "costo_cero_con_existencia": 28,
  "filas_llave_repetida": 1788,
  "filas_exactas_repetidas": 76,
  "costo_inventario_no_cuadra": 0,
  "iva_no_es_116": 7,
  "skus_con_varios_costos_misma_fecha": 0,
  "piezas_ultimo_corte": 969762,
  "valor_ultimo_corte": 305740664.07,
  "copias_exactas_con_existencia_ultimo_corte": {
   "filas": 4,
   "piezas": 7005,
   "valor": 1081710.45,
   "nota": "No se eliminan: pueden ser lotes/series distintos del mismo SKU. Se reportan para que se confirme en el origen."
  },
  "piezas_por_corte": {
   "2026-10-01": 809737,
   "2026-10-02": 817039,
   "2026-10-05": 795299,
   "2026-10-09": 839823,
   "2026-10-12": 818947,
   "2026-10-16": 996742,
   "2026-10-19": 963236,
   "2026-10-21": 969762
  }
 },
 "ERP": {
  "filas": 183724,
  "columnas": [
   "Fecha",
   "Tienda",
   "Almacen",
   "Categoria",
   "Marca/Clasificacion",
   "SKU CORRECTO",
   "Titulo",
   "Ubicacion",
   "Total",
   "Costo",
   "Costo Inventario",
   "Costo Inventario + IVA"
  ],
  "cortes": [
   "2026-10-01",
   "2026-10-02",
   "2026-10-05",
   "2026-10-09",
   "2026-10-12",
   "2026-10-16",
   "2026-10-19",
   "2026-10-21"
  ],
  "skus": 4368,
  "tiendas": [
   "BHBE",
   "MEDICAL STORE",
   "MISS ROU",
   "MX LOVERS",
   "NEXU STORE",
   "SELECTSHOP",
   "T-LAB"
  ],
  "canales_o_almacenes": [
   "IZTAPALAPA",
   "NAUCALPAN",
   "TEPOTZOTLAN 2",
   "TEPOTZOTLAN 3",
   "TEPOTZOTLAN 3 - MR",
   "TEPOTZOTLAN 3 - MXL",
   "TEPOTZOTLAN 4"
  ],
  "ubicaciones_o_estatus": [
   "ACUMULADO",
   "Almacen 7A",
   "Almacen 7B",
   "General",
   "HUB",
   "Proveedores",
   "Venta Deysa",
   "Venta Directa",
   "Venta Mayoreo",
   "Venta Mermas",
   "Venta MxLovers",
   "Venta Xitelly",
   "acumulado"
  ],
  "nulos": {},
  "titulos_con_error": 0,
  "skus_titulo_error": [],
  "total_negativo": 0,
  "costo_cero_con_existencia": 0,
  "filas_llave_repetida": 43826,
  "filas_exactas_repetidas": 28756,
  "costo_inventario_no_cuadra": 0,
  "iva_no_es_116": 16,
  "skus_con_varios_costos_misma_fecha": 0,
  "piezas_ultimo_corte": 4522822,
  "valor_ultimo_corte": 322227063.23,
  "copias_exactas_con_existencia_ultimo_corte": {
   "filas": 43,
   "piezas": 7658,
   "valor": 3426500.21,
   "nota": "No se eliminan: pueden ser lotes/series distintos del mismo SKU. Se reportan para que se confirme en el origen."
  },
  "piezas_por_corte": {
   "2026-10-01": 4218971,
   "2026-10-02": 4208733,
   "2026-10-05": 4203243,
   "2026-10-09": 4638055,
   "2026-10-12": 4635569,
   "2026-10-16": 4633353,
   "2026-10-19": 4660490,
   "2026-10-21": 4522822
  }
 },
 "relacion_erp_plataformas": {
  "corte": "2026-10-21",
  "skus_solo_erp": 2765,
  "skus_solo_plataformas": 741,
  "skus_en_ambas": 1291,
  "piezas_plataformas_en_skus_tambien_erp": 858226,
  "piezas_por_tienda": {
   "ARMAF": {
    "ERP": 0,
    "PLATAFORMAS": 4908
   },
   "BHBE": {
    "ERP": 2385818,
    "PLATAFORMAS": 0
   },
   "MEDICAL STORE": {
    "ERP": 333013,
    "PLATAFORMAS": 80778
   },
   "MISS ROU": {
    "ERP": 33047,
    "PLATAFORMAS": 20635
   },
   "MX LOVERS": {
    "ERP": 1,
    "PLATAFORMAS": 488
   },
   "NEXU STORE": {
    "ERP": 93607,
    "PLATAFORMAS": 174979
   },
   "OCENID": {
    "ERP": 0,
    "PLATAFORMAS": 99551
   },
   "SELECTSHOP": {
    "ERP": 1164565,
    "PLATAFORMAS": 516687
   },
   "SIGNA": {
    "ERP": 0,
    "PLATAFORMAS": 66559
   },
   "T-LAB": {
    "ERP": 512771,
    "PLATAFORMAS": 5177
   }
  },
  "nota": "Las dos fuentes son existencias distintas (almacenes ERP vs. inventario en plataformas); no se pueden cruzar pieza a pieza sin una llave física. El dashboard las muestra por separado y su suma solo en 'Todos'."
 },
 "disponible": {
  "corte": "2026-10-21",
  "empresas_con_archivo": [
   "BHBE",
   "MEDICAL STORE",
   "NEXU STORE",
   "SELECTSHOP"
  ],
  "empresas_sin_archivo": [
   "T-LAB"
  ],
  "disponible": 3933790,
  "comprometido": 91638,
  "erp_total_mismas_tiendas": 3977003,
  "skus_disp_mas_comprometido_mayor_que_erp_total": 1350,
  "piezas_exceso": 122711,
  "nota": "Disponible y comprometido son una clasificación del mismo stock del ERP (no se suman al total)."
 },
 "indicadores": {
  "valor_total_y_piezas": "Calculable (Total, Costo Inventario por corte).",
  "variacion_vs_periodo_anterior": "Calculable entre cortes consecutivos de cada fuente.",
  "valor_vendible_no_vendible": "Plataformas: calculable por estatus ('Aptas para vender' = vendible). ERP: solo con los archivos DISPONIBLE (un corte, 4 de 5 empresas); no existe estatus de venta en el concentrado ERP.",
  "inventario_por_canal": "Calculable (columna Plataforma).",
  "inventario_por_almacen_y_ubicacion": "Calculable (columnas Almacen y Ubicacion del ERP).",
  "movimientos": "Calculable como variación de existencias entre cortes (no hay ventas ni compras en los concentrados).",
  "sin_movimiento": "Calculable con los cortes disponibles; la precisión depende de la frecuencia de cortes (hoy cada 1-4 días).",
  "no_disponible": [
   "Ventas / rotación real en unidades vendidas",
   "Precio de venta y margen",
   "Fecha de entrada del producto (antigüedad real)",
   "Disponible/reservado histórico (solo hay un corte)",
   "Disponible de T-LAB"
  ]
 }
};
